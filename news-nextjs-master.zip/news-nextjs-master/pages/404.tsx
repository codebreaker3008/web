const NotFoundPage = () => {
    return ( 
        <div>
            <h1>Not Found</h1>
            <p>Looks like this page does not exist!</p>
        </div>
     );
}
 
export default NotFoundPage;