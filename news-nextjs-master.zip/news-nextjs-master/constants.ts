export const INPUT_MAX_LENGTH = 500;
export const BASE_URL = 'https://news.turskyi.com/';